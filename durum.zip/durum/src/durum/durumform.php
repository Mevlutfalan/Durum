<?php

namespace durum;

use durum\main;
use pocketmine\form\Form;
use pocketmine\{Player, Server};

class durumform implements Form{
	 
	 public $p;
	 
	 public function __construct(Player $p){
	 	$this->p = $p;
	 }
	 
	public function jsonSerialize(): array{
	    $text = "";
	    if (isset(main::$durumData[$this->p->getName()])) { // durum datada ismim varsa
	        $text .= main::$durumData[$this->p->getName()]; // texte durumu yazdir
	    } else {
	        $text .= "Yok"; // yok ise "Yok" yazdir
	    }
	    return [
	        "type" => "custom_form",
	        "title" => "Durum Menüsü",
	        "content" => [
	            ["type" => "input", "text" => "Not: Durumun Tagının Altında Gözükmektedir. \nDurumun - " . $text . "\n", "placeholder" => "", "default" => null]
	            // bu fonksiyon icinde arrayi olusturmadigim icin $this->array yani bu siniftaki array eger bu fonksiyonda olustursaydik $array
	       ]
	   ];
	}
	public function handleResponse(Player $p, $data): void{
		if(is_null($data)){
			return;
		}
		if($data[0] != null){
			$p->setScoreTag($data[0]);
			main::$durumData[$p->getName()] = $data[0];
			$p->sendMessage("Durumun " . $data[0] . " Olarak Değiştirilmiştir");
		}else{
			$p->sendMessage("Burası Boş Bırakılamaz");
		}
	}
}