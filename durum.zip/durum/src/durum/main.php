<?php

namespace durum;

use pocketmine\plugin\PluginBase;
use pocketmine\{Player, Server};
use durum\cmd;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class main extends PluginBase implements Listener{
    
    public static $durumData = []; // array 
	
	public function onEnable(){
		$this->getLogger()->info("Aktif");
		$this->getServer()->getCommandMap()->register("durum", new cmd());
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function onJoin (PlayerJoinEvent $e){
	    if (isset(self::$durumData[$e->getPlayer()->getName()])) { // durum datada ismim var ise
	        $e->getPlayer()->setScoreTag(self::$durumData[$e->getPlayer()->getName()]); // set score tag ve durum datayi sil
	    }
	}
}