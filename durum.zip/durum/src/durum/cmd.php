<?php

namespace durum;

use pocketmine\{Player, Server};
use pocketmine\command\{Command, CommandSender};
use durum\durumform;

class cmd extends Command{
	
	public function __construct(){
		parent::__construct("durum", "Durumunu Ayarla", "/durum");
	}
	public function execute(CommandSender $p, string $label, array $args){
		if($p instanceof Player){
		    if (!empty($args[0])) {
		        if ($args[0] === "sil") {
		            unset(main::$durumData[$p->getName()]); // durum datayi sifirla
		            $p->setScoreTag("");
		            $p->sendMessage("Durum Silindi!"); 
		        }
		    } else {
		        $p->sendForm(new durumform($p));
		    }
		}
	}
}